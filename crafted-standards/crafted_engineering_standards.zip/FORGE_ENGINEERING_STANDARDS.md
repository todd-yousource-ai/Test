# Crafted Engineering Standards

## Core Principles
- All code must be engineered for maximum security.
- All code must be engineered for maximum performance.
- All code must be engineered for simplicity, clarity, maintainability, and traceability.
- Security, correctness, documentation, and operational integrity take priority over development speed.
- Do not introduce complexity unless it is required and justified.

## Security Requirements
- Default to secure-by-design and deny-by-default behavior.
- All trust boundaries must be explicitly identified and enforced.
- All sensitive operations must be authenticated, authorized, and fully auditable.
- All secrets, keys, tokens, and credentials must be protected in memory, at rest, and in transit.
- Never hardcode secrets, tokens, credentials, or cryptographic material.
- All external input must be treated as untrusted and validated strictly.
- All parsing must be bounds-checked and fail safely.
- All failures involving trust, identity, policy, or cryptography must fail closed.
- All administrative or policy-changing actions must generate audit logs.
- Minimize attack surface, dependencies, privileges, and exposed interfaces.
- Any library used for cryptographic or regulated security functions must support FIPS 140-3 validated usage where required.
- Avoid libraries with weak maintenance history, unclear provenance, or unnecessary bloat.

## Performance Requirements
- Performance must be considered a design requirement, not a post-build optimization.
- Favor low-latency, low-overhead architectures.
- Avoid unnecessary allocations, copies, blocking calls, and serialization overhead.
- Measure hot paths, do not guess.
- All network, crypto, policy, and telemetry paths must be benchmarked.
- Design for efficient concurrency and safe parallelism where appropriate.
- Startup time, steady-state latency, and resource usage must be explicitly evaluated.
- Dependencies that materially degrade performance must be rejected.

## Code Quality Requirements
- Code must be production-grade, not demo-grade.
- Code must be readable, deterministic, and easy to review.
- Prefer explicit behavior over magic abstractions.
- Prefer small, composable modules over large multipurpose components.
- Every major component must have clear ownership, interfaces, and failure behavior.
- Remove dead code, unused dependencies, and experimental leftovers.
- No silent failure paths.
- No TODOs in security-critical or runtime-critical code without tracked follow-up.

## Dependency Requirements
- Every dependency must be justified.
- Prefer mature, actively maintained, minimal dependencies.
- Prefer first-party implementation over third-party packages when the function is security-critical and feasible to own.
- All dependencies must be reviewed for licensing, maintenance health, CVE history, and transitive risk.
- Reduce transitive dependency chains wherever possible.
- Do not add a dependency for convenience if the functionality is small and can be safely implemented internally.

## Cryptography Requirements
- Use modern, well-vetted cryptographic primitives only.
- Do not invent cryptography.
- Cryptographic design decisions must be documented.
- Key generation, storage, rotation, destruction, and recovery paths must be defined.
- Randomness must come from approved cryptographic sources.
- Separate identity, encryption, signing, and session material appropriately.
- Cryptographic failure must never degrade silently into insecure behavior.

## Observability and Auditability
- All critical actions must be observable through structured logs, metrics, and telemetry.
- Logs must support forensic reconstruction without exposing secrets.
- Security-relevant events must be timestamped, attributable, and tamper-evident where possible.
- Build with operational diagnostics from the start, not as an afterthought.

## Testing Requirements
- All security-critical logic must have unit, integration, and negative-path tests.
- All parsing, policy, trust, and cryptographic logic must be tested against malformed inputs.
- Test for failure behavior, not just success behavior.
- Add regression tests for every material bug.
- Benchmark tests must exist for performance-sensitive paths.
- Fuzzing should be used where inputs are complex, attacker-controlled, or parser-driven.

## Platform and Runtime Requirements
- Design for least privilege on every platform.
- Minimize kernel, driver, and privileged runtime exposure unless absolutely required.
- Platform-specific code must preserve equivalent security guarantees wherever possible.
- Runtime isolation and sandboxing should be used wherever meaningful.

## Code Traceability and Documentation Requirements
- Every major module, service, library, and security-critical function must have a clearly documented purpose.
- Every material code path must be traceable to a requirement, design decision, security need, or bug fix.
- All repositories must maintain clear mapping between requirements, design documents, implementation components, and tests.
- Comments must explain why, assumptions, constraints, and failure behavior, not merely restate code.
- Public interfaces, protocol handlers, policy enforcement paths, and critical data flows must be documented.
- All significant architectural decisions must be captured in ADRs or equivalent design records.
- AI-generated code must meet the same review, traceability, and documentation standards as human-written code.
- No major component should exist without clear documentation of its purpose, dependencies, and operational assumptions.

## Required Traceability Artifacts
- README.md must explain the purpose of the repository, how to build it, how to test it, and how it fits into Crafted.
- ARCHITECTURE.md must describe the system components, boundaries, major flows, and dependencies.
- SECURITY.md must describe trust boundaries, sensitive assets, threat assumptions, and secure handling requirements.
- DECISIONS.md or ADRs must record important design and implementation decisions.
- TESTING.md must describe unit, integration, negative-path, fuzz, and benchmark coverage where applicable.
- CHANGELOG.md must record material behavioral, security, and interface changes.

## Crafted Architecture Rules
- Trust must never be inferred implicitly when it can be asserted and verified explicitly.
- Identity, policy, telemetry, and enforcement must remain separable but tightly linked.
- All control decisions must be explainable, observable, and reproducible.
- Crafted components must default to policy enforcement, not policy suggestion.
- Local agents must minimize user friction while preserving strong enforcement guarantees.
- Administrative workflows must be simple, explicit, and understandable in plain language.
- Protocol and enforcement logic must be designed for future scale across endpoint, network, cloud, and AI runtime environments.
## Crafted Component Interface Contracts

Every Crafted component MUST implement these contracts or the component is non-conformant.
These are not guidelines — they are hard requirements enforced at code review.

### CAL Enforcement Contract
- Every entry point that processes an agent action MUST call CTX-ID validation FIRST
- CTX-ID validation failure MUST result in immediate rejection — no partial processing
- Every action MUST be checked against VTZ policy BEFORE execution
- VTZ policy denial MUST produce a VTZEnforcementDecision record with verdict=block
- Every action outcome (allow, restrict, block) MUST emit a TrustFlow event
- TrustFlow emission failure MUST NOT silently continue — log and surface the failure

### TrustFlow Emission Contract
- Every TrustFlow event MUST include: event_id, session_id, ctx_id, ts, event_type, payload_hash
- event_id MUST be globally unique (CSPRNG, not sequential)
- ts MUST be UTC Unix timestamp with millisecond precision
- payload_hash MUST be SHA-256 of the serialized action payload
- Emission MUST be synchronous in the enforcement path — async buffering is not permitted
- Failed emission is a WARN-level audit event, not a silent skip

### CTX-ID Contract
- CTX-ID tokens are IMMUTABLE once issued — no field modification after issuance
- CTX-ID rotation creates a new token; the old one is invalidated immediately
- Expired CTX-ID MUST be rejected — clock skew tolerance is defined per deployment
- CTX-ID MUST be validated against TrustLock public key — software-only validation is rejected
- Missing CTX-ID MUST be treated as UNTRUSTED — never infer identity from context

### VTZ Enforcement Contract
- Every agent session is bound to EXACTLY ONE VTZ at CTX-ID issuance
- Cross-VTZ tool calls require explicit policy authorization — implicit is denied
- VTZ boundaries are structural, not advisory — enforcement cannot be bypassed by application code
- VTZ policy changes take effect at NEXT CTX-ID issuance, not mid-session

### DTL Label Contract
- Labels are assigned at DATA INGESTION and are immutable thereafter
- Label inheritance: derived data inherits the HIGHEST classification of any source
- Unlabeled data MUST be treated as CONFIDENTIAL until explicitly reclassified
- Label verification MUST occur before any data crosses a trust boundary
- Label stripping is a security event that MUST be audited and policy-controlled

### Error Handling Contract
- All trust, identity, policy, and cryptographic failures MUST fail CLOSED
- Fail closed means: reject the action, log the event, surface to caller — never silently continue
- No swallowed exceptions in enforcement paths (try/except/pass is BANNED in enforcement code)
- All errors MUST include: component, operation, failure_reason, ctx_id (if available)
- Error messages MUST NOT include: keys, tokens, secrets, or cleartext payloads

### Audit Contract
- Every security-relevant action MUST generate an audit record BEFORE execution
- Audit records are APPEND-ONLY — no modification or deletion
- Audit failures are NON-FATAL to agent operation but MUST be surfaced immediately
- Audit records MUST NOT contain: secrets, keys, tokens, or cleartext sensitive data
- Replay MUST be possible from the audit stream alone (no external state required)

### Test Requirements Contract
- Every enforcement path MUST have a negative test (what happens on rejection)
- Every cryptographic operation MUST have a test with invalid/expired material
- Every TrustFlow emission MUST be tested for both success and failure paths
- Tests MUST NOT mock the enforcement decision — they may mock the external call but the logic must run
- Test coverage for enforcement paths MUST be >= 90%

## Crafted File Naming Conventions

src/cal/           - Conversation Abstraction Layer components
src/dtl/           - Data Trust Label components
src/trustflow/     - TrustFlow audit stream components
src/vtz/           - Virtual Trust Zone enforcement
src/trustlock/     - Cryptographic machine identity (TPM-anchored)
src/mcp/           - MCP Policy Engine
src/rewind/        - Crafted Rewind replay engine
sdk/connector/     - Crafted Connector SDK
tests/<subsystem>/ - Tests mirror src/ structure exactly

## Crafted Code Review Checklist

Before any PR is merged, a reviewer MUST confirm:
[ ] CTX-ID validated at every enforcement entry point
[ ] TrustFlow event emitted for every action outcome
[ ] VTZ policy checked before cross-boundary operations
[ ] No silent failure paths in trust/crypto/policy code
[ ] No secrets, keys, or tokens in logs or error messages
[ ] All external input validated before use
[ ] Test coverage includes at least one negative path per security boundary
[ ] FIPS-approved algorithms used for all cryptographic operations
